﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient ;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace locadoranoite
{
    public partial class Form1 : Form
    {
            private SqlConnection conexao; //faz parte da systemdata
            private SqlDataAdapter adapter;//faz parte da systemdata
        private DataTable tblfuncionarios; // faz parte da system data sqlcliente
        private string strsql, strconex;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        
    }
        private void btentrar_Click(object sender, EventArgs e)
        {
            strconex = "data source=(local);initial catalog=locadora;integrated security=sspi";

            conexao = new SqlConnection(strconex);
            conexao.Open();

            tblfuncionarios=new DataTable ();
            strsql = "select * from funcionarios where usuario='" + txtusuario.Text + "' and senha= '" + txtsenha.Text + "'";// ou usuario'ana' and senha='123'";
            adapter = new SqlDataAdapter(strsql, conexao);
            adapter.Fill(tblfuncionarios);

            if (tblfuncionarios.Rows.Count == 1) // se o numero de linhas da tabela funcionarios for igual a 1
            {
                string nomedoFuncionario = tblfuncionarios.Rows[0]["nomefunc"].ToString();
                string nivelDoFuncionario = tblfuncionarios.Rows[0]["nivel"].ToString();
                Principal princ = new Principal();/*declara e instancia um obejto para abrir o formulario Principal
                                                   princ e como se fosse uma variavel para o formulario que esta sendo aberto */
                princ.nome = nomedoFuncionario;
                princ.Show(); //abre o formulario
                this.Hide();/* oculta o formulario, para manter o formulario de login aberto (que é o primeiro, que 
                             * nao pode ser fechado)
                             */

                MessageBox.Show("Seja Bem vindo", "Mensagem",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao entrar no sistema, confira usuário e senha", "Mensagem",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
            }

        }

        }
    }

