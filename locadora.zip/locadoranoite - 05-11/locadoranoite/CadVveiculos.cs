﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace locadoranoite
{
    public partial class CadVveiculos : Form
    {
        private SqlConnection conexao;
        private SqlCommand comando;
        private SqlDataAdapter adapter; //para alimentar a combobox
        private DataTable tblcategorias; //para alimentar a combobox para uma
        private string strconex, strsql;

        public CadVveiculos()
        {
            InitializeComponent();
        }

        private void cbocodcategoria_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblcodcategoria.Text = cbocodcategoria.SelectedValue.ToString();
        }

        private void CadVveiculos_Load(object sender, EventArgs e)
        {
            strconex = "data source=(local);" +
                "initial catalog = locadora; Integrated security=SSPI";
            conexao = new SqlConnection(strconex);
            conexao.Open();

            strsql = "Select * from Categorias";
            adapter = new SqlDataAdapter(strsql, conexao);

            tblcategorias = new DataTable();
             
            adapter.Fill(tblcategorias);

            cbocodcategoria.DataSource = tblcategorias;
            cbocodcategoria.DisplayMember = "categoria";//o que eu quero mostrar na caixa
            cbocodcategoria.ValueMember = "codcategoria";// tem que escrever do jeito que esta escrito no banco de dados

            lblcodcategoria.Text = cbocodcategoria.SelectedValue.ToString();


        }

        private void btgravar_Click(object sender, EventArgs e)
        {
            strconex = "data source=(local);" +
                "initial catalog = locadora; Integrated security=SSPI";
            conexao = new SqlConnection(strconex);
            conexao.Open();
            strsql = "insert into veiculos (Marca, Modelo, Cor, Placa, Ano, CodCategoria,imagem) " +
                " values('"+txtmarca.Text+"', '"+txtmodelo.Text+"','"+txtcor.Text+"','"+txtplaca.Text+"'," +
                "'"+txtano.Text+"','"+cbocodcategoria+"','nenhum.jpg')";
            comando = new SqlCommand(strsql, conexao);
            comando.ExecuteNonQuery();
            MessageBox.Show("Registro gravado com sucesso!",
                "aviso",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            Close();

            //para registrar o que foi digitado na caixa de texto do programa

            /*
           ('tesla', 'Eletric','prata','tes-555'," +
                "'2018','3','nenhum.jpg')";
             */
        }

        private void btcancelar_Click(object sender, EventArgs e)
        {

        }

        private void btok_Click(object sender, EventArgs e)
        {
            int i = 0;
            bool achei = false, valida = false;
            string nomecompleto, nomearquivo = "", enderecoarquivo;
            do
            {
                open.ShowDialog();//entrar na cx de dialogo
                picimagem.Load(open.FileName);
                nomecompleto = open.FileName;
                //recortar o nome do arquivo e verificar se ele esta na pasta veículos
                for (i = nomecompleto.Length - 1; i >= 0; i--) //para comecar da posicao 0
                {
                    if (nomecompleto[i] == '\\')
                    {
                        nomearquivo = nomecompleto.Substring(i + 1, (nomecompleto.Length - 1) - (i));
                        break;
                    }
                }//digitou até aqui
                enderecoarquivo = nomecompleto.Substring(0, i - 1);
                this.Text = enderecoarquivo;

                if (Application.StartupPath /* pega o end. do executavel*/ + "\\veiculo" == enderecoarquivo)
                {
                    valida = true;
                }
                else
                {
                    MessageBox.Show("Escolha uma imagem da pasta veiculo");
                }

            } while (valida == false);
            txtimagem.Text = nomearquivo;

        }//fim do btok
    }
}
