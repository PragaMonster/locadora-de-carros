﻿namespace locadoranoite
{
    partial class CodFuncionarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblnome = new System.Windows.Forms.Label();
            this.lblendereço = new System.Windows.Forms.Label();
            this.lblbairro = new System.Windows.Forms.Label();
            this.lblcidade = new System.Windows.Forms.Label();
            this.lblcargo = new System.Windows.Forms.Label();
            this.lblusuario = new System.Windows.Forms.Label();
            this.lblsenha = new System.Windows.Forms.Label();
            this.lblnivel = new System.Windows.Forms.Label();
            this.lblcodnivel = new System.Windows.Forms.Label();
            this.txtnome = new System.Windows.Forms.TextBox();
            this.txtendereco = new System.Windows.Forms.TextBox();
            this.txtbairro = new System.Windows.Forms.TextBox();
            this.txtcidade = new System.Windows.Forms.TextBox();
            this.txtcargo = new System.Windows.Forms.TextBox();
            this.txtusuario = new System.Windows.Forms.TextBox();
            this.txtsenha = new System.Windows.Forms.TextBox();
            this.txtnivel = new System.Windows.Forms.TextBox();
            this.txtcodcli = new System.Windows.Forms.TextBox();
            this.btgravar = new System.Windows.Forms.Button();
            this.btcancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblnome
            // 
            this.lblnome.AutoSize = true;
            this.lblnome.Location = new System.Drawing.Point(41, 62);
            this.lblnome.Name = "lblnome";
            this.lblnome.Size = new System.Drawing.Size(38, 13);
            this.lblnome.TabIndex = 0;
            this.lblnome.Text = "Nome:";
            // 
            // lblendereço
            // 
            this.lblendereço.AutoSize = true;
            this.lblendereço.Location = new System.Drawing.Point(41, 100);
            this.lblendereço.Name = "lblendereço";
            this.lblendereço.Size = new System.Drawing.Size(56, 13);
            this.lblendereço.TabIndex = 1;
            this.lblendereço.Text = "Endereço:";
            // 
            // lblbairro
            // 
            this.lblbairro.AutoSize = true;
            this.lblbairro.Location = new System.Drawing.Point(41, 135);
            this.lblbairro.Name = "lblbairro";
            this.lblbairro.Size = new System.Drawing.Size(37, 13);
            this.lblbairro.TabIndex = 2;
            this.lblbairro.Text = "Bairro:";
            this.lblbairro.Click += new System.EventHandler(this.label3_Click);
            // 
            // lblcidade
            // 
            this.lblcidade.AutoSize = true;
            this.lblcidade.Location = new System.Drawing.Point(41, 174);
            this.lblcidade.Name = "lblcidade";
            this.lblcidade.Size = new System.Drawing.Size(43, 13);
            this.lblcidade.TabIndex = 3;
            this.lblcidade.Text = "Cidade:";
            // 
            // lblcargo
            // 
            this.lblcargo.AutoSize = true;
            this.lblcargo.Location = new System.Drawing.Point(41, 215);
            this.lblcargo.Name = "lblcargo";
            this.lblcargo.Size = new System.Drawing.Size(38, 13);
            this.lblcargo.TabIndex = 4;
            this.lblcargo.Text = "Cargo ";
            // 
            // lblusuario
            // 
            this.lblusuario.AutoSize = true;
            this.lblusuario.Location = new System.Drawing.Point(41, 255);
            this.lblusuario.Name = "lblusuario";
            this.lblusuario.Size = new System.Drawing.Size(46, 13);
            this.lblusuario.TabIndex = 5;
            this.lblusuario.Text = "Usuario:";
            // 
            // lblsenha
            // 
            this.lblsenha.AutoSize = true;
            this.lblsenha.Location = new System.Drawing.Point(41, 292);
            this.lblsenha.Name = "lblsenha";
            this.lblsenha.Size = new System.Drawing.Size(38, 13);
            this.lblsenha.TabIndex = 6;
            this.lblsenha.Text = "Senha";
            // 
            // lblnivel
            // 
            this.lblnivel.AutoSize = true;
            this.lblnivel.Location = new System.Drawing.Point(41, 333);
            this.lblnivel.Name = "lblnivel";
            this.lblnivel.Size = new System.Drawing.Size(34, 13);
            this.lblnivel.TabIndex = 7;
            this.lblnivel.Text = "Nivel:";
            // 
            // lblcodnivel
            // 
            this.lblcodnivel.AutoSize = true;
            this.lblcodnivel.Location = new System.Drawing.Point(41, 374);
            this.lblcodnivel.Name = "lblcodnivel";
            this.lblcodnivel.Size = new System.Drawing.Size(78, 13);
            this.lblcodnivel.TabIndex = 8;
            this.lblcodnivel.Text = "Codigo Cliente:";
            // 
            // txtnome
            // 
            this.txtnome.Location = new System.Drawing.Point(131, 51);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(117, 20);
            this.txtnome.TabIndex = 9;
            // 
            // txtendereco
            // 
            this.txtendereco.Location = new System.Drawing.Point(131, 97);
            this.txtendereco.Name = "txtendereco";
            this.txtendereco.Size = new System.Drawing.Size(116, 20);
            this.txtendereco.TabIndex = 10;
            // 
            // txtbairro
            // 
            this.txtbairro.Location = new System.Drawing.Point(131, 134);
            this.txtbairro.Name = "txtbairro";
            this.txtbairro.Size = new System.Drawing.Size(115, 20);
            this.txtbairro.TabIndex = 11;
            // 
            // txtcidade
            // 
            this.txtcidade.Location = new System.Drawing.Point(131, 176);
            this.txtcidade.Name = "txtcidade";
            this.txtcidade.Size = new System.Drawing.Size(115, 20);
            this.txtcidade.TabIndex = 12;
            // 
            // txtcargo
            // 
            this.txtcargo.Location = new System.Drawing.Point(131, 208);
            this.txtcargo.Name = "txtcargo";
            this.txtcargo.Size = new System.Drawing.Size(116, 20);
            this.txtcargo.TabIndex = 13;
            // 
            // txtusuario
            // 
            this.txtusuario.Location = new System.Drawing.Point(131, 255);
            this.txtusuario.Name = "txtusuario";
            this.txtusuario.Size = new System.Drawing.Size(114, 20);
            this.txtusuario.TabIndex = 14;
            // 
            // txtsenha
            // 
            this.txtsenha.Location = new System.Drawing.Point(131, 291);
            this.txtsenha.Name = "txtsenha";
            this.txtsenha.Size = new System.Drawing.Size(113, 20);
            this.txtsenha.TabIndex = 15;
            // 
            // txtnivel
            // 
            this.txtnivel.Location = new System.Drawing.Point(131, 335);
            this.txtnivel.Name = "txtnivel";
            this.txtnivel.Size = new System.Drawing.Size(112, 20);
            this.txtnivel.TabIndex = 16;
            // 
            // txtcodcli
            // 
            this.txtcodcli.Location = new System.Drawing.Point(133, 372);
            this.txtcodcli.Name = "txtcodcli";
            this.txtcodcli.Size = new System.Drawing.Size(109, 20);
            this.txtcodcli.TabIndex = 17;
            // 
            // btgravar
            // 
            this.btgravar.Location = new System.Drawing.Point(41, 428);
            this.btgravar.Name = "btgravar";
            this.btgravar.Size = new System.Drawing.Size(62, 29);
            this.btgravar.TabIndex = 18;
            this.btgravar.Text = "Gravar";
            this.btgravar.UseVisualStyleBackColor = true;
            this.btgravar.Click += new System.EventHandler(this.btgravar_Click);
            // 
            // btcancelar
            // 
            this.btcancelar.Location = new System.Drawing.Point(229, 424);
            this.btcancelar.Name = "btcancelar";
            this.btcancelar.Size = new System.Drawing.Size(71, 32);
            this.btcancelar.TabIndex = 19;
            this.btcancelar.Text = "Cancelar";
            this.btcancelar.UseVisualStyleBackColor = true;
            // 
            // CodFuncionarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(429, 474);
            this.Controls.Add(this.btcancelar);
            this.Controls.Add(this.btgravar);
            this.Controls.Add(this.txtcodcli);
            this.Controls.Add(this.txtnivel);
            this.Controls.Add(this.txtsenha);
            this.Controls.Add(this.txtusuario);
            this.Controls.Add(this.txtcargo);
            this.Controls.Add(this.txtcidade);
            this.Controls.Add(this.txtbairro);
            this.Controls.Add(this.txtendereco);
            this.Controls.Add(this.txtnome);
            this.Controls.Add(this.lblcodnivel);
            this.Controls.Add(this.lblnivel);
            this.Controls.Add(this.lblsenha);
            this.Controls.Add(this.lblusuario);
            this.Controls.Add(this.lblcargo);
            this.Controls.Add(this.lblcidade);
            this.Controls.Add(this.lblbairro);
            this.Controls.Add(this.lblendereço);
            this.Controls.Add(this.lblnome);
            this.Name = "CodFuncionarios";
            this.Text = "CodFuncionarios";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblnome;
        private System.Windows.Forms.Label lblendereço;
        private System.Windows.Forms.Label lblbairro;
        private System.Windows.Forms.Label lblcidade;
        private System.Windows.Forms.Label lblcargo;
        private System.Windows.Forms.Label lblusuario;
        private System.Windows.Forms.Label lblsenha;
        private System.Windows.Forms.Label lblnivel;
        private System.Windows.Forms.Label lblcodnivel;
        private System.Windows.Forms.TextBox txtnome;
        private System.Windows.Forms.TextBox txtendereco;
        private System.Windows.Forms.TextBox txtbairro;
        private System.Windows.Forms.TextBox txtcidade;
        private System.Windows.Forms.TextBox txtcargo;
        private System.Windows.Forms.TextBox txtusuario;
        private System.Windows.Forms.TextBox txtsenha;
        private System.Windows.Forms.TextBox txtnivel;
        private System.Windows.Forms.TextBox txtcodcli;
        private System.Windows.Forms.Button btgravar;
        private System.Windows.Forms.Button btcancelar;
    }
}