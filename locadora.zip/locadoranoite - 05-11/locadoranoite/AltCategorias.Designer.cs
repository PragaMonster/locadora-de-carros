﻿namespace locadoranoite
{
    partial class AltCategorias
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grupo1 = new System.Windows.Forms.GroupBox();
            this.grupo2 = new System.Windows.Forms.GroupBox();
            this.lblcodcategoria = new System.Windows.Forms.Label();
            this.txtcodcategoria = new System.Windows.Forms.TextBox();
            this.btalterar = new System.Windows.Forms.Button();
            this.lblcategoria = new System.Windows.Forms.Label();
            this.lbldescricao = new System.Windows.Forms.Label();
            this.lblvalor = new System.Windows.Forms.Label();
            this.txtcategoria = new System.Windows.Forms.TextBox();
            this.txtdescricao = new System.Windows.Forms.TextBox();
            this.txtvalor = new System.Windows.Forms.TextBox();
            this.btgravar = new System.Windows.Forms.Button();
            this.btcancelar = new System.Windows.Forms.Button();
            this.grupo1.SuspendLayout();
            this.grupo2.SuspendLayout();
            this.SuspendLayout();
            // 
            // grupo1
            // 
            this.grupo1.Controls.Add(this.btalterar);
            this.grupo1.Controls.Add(this.txtcodcategoria);
            this.grupo1.Controls.Add(this.lblcodcategoria);
            this.grupo1.Location = new System.Drawing.Point(26, 52);
            this.grupo1.Name = "grupo1";
            this.grupo1.Size = new System.Drawing.Size(624, 102);
            this.grupo1.TabIndex = 0;
            this.grupo1.TabStop = false;
            // 
            // grupo2
            // 
            this.grupo2.Controls.Add(this.btcancelar);
            this.grupo2.Controls.Add(this.btgravar);
            this.grupo2.Controls.Add(this.txtvalor);
            this.grupo2.Controls.Add(this.txtdescricao);
            this.grupo2.Controls.Add(this.txtcategoria);
            this.grupo2.Controls.Add(this.lblvalor);
            this.grupo2.Controls.Add(this.lbldescricao);
            this.grupo2.Controls.Add(this.lblcategoria);
            this.grupo2.Location = new System.Drawing.Point(27, 200);
            this.grupo2.Name = "grupo2";
            this.grupo2.Size = new System.Drawing.Size(622, 311);
            this.grupo2.TabIndex = 1;
            this.grupo2.TabStop = false;
            // 
            // lblcodcategoria
            // 
            this.lblcodcategoria.AutoSize = true;
            this.lblcodcategoria.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcodcategoria.Location = new System.Drawing.Point(28, 47);
            this.lblcodcategoria.Name = "lblcodcategoria";
            this.lblcodcategoria.Size = new System.Drawing.Size(108, 16);
            this.lblcodcategoria.TabIndex = 0;
            this.lblcodcategoria.Text = "Cod.Categoria";
            // 
            // txtcodcategoria
            // 
            this.txtcodcategoria.Location = new System.Drawing.Point(142, 42);
            this.txtcodcategoria.Name = "txtcodcategoria";
            this.txtcodcategoria.Size = new System.Drawing.Size(263, 20);
            this.txtcodcategoria.TabIndex = 1;
            // 
            // btalterar
            // 
            this.btalterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btalterar.Location = new System.Drawing.Point(459, 41);
            this.btalterar.Name = "btalterar";
            this.btalterar.Size = new System.Drawing.Size(99, 35);
            this.btalterar.TabIndex = 2;
            this.btalterar.Text = "Alterar";
            this.btalterar.UseVisualStyleBackColor = true;
            this.btalterar.Click += new System.EventHandler(this.btalterar_Click);
            // 
            // lblcategoria
            // 
            this.lblcategoria.AutoSize = true;
            this.lblcategoria.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcategoria.Location = new System.Drawing.Point(45, 45);
            this.lblcategoria.Name = "lblcategoria";
            this.lblcategoria.Size = new System.Drawing.Size(80, 16);
            this.lblcategoria.TabIndex = 0;
            this.lblcategoria.Text = "Categoria:";
            // 
            // lbldescricao
            // 
            this.lbldescricao.AutoSize = true;
            this.lbldescricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldescricao.Location = new System.Drawing.Point(44, 96);
            this.lbldescricao.Name = "lbldescricao";
            this.lbldescricao.Size = new System.Drawing.Size(83, 16);
            this.lbldescricao.TabIndex = 1;
            this.lbldescricao.Text = "Descrição:";
            // 
            // lblvalor
            // 
            this.lblvalor.AutoSize = true;
            this.lblvalor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvalor.Location = new System.Drawing.Point(53, 151);
            this.lblvalor.Name = "lblvalor";
            this.lblvalor.Size = new System.Drawing.Size(49, 16);
            this.lblvalor.TabIndex = 2;
            this.lblvalor.Text = "Valor:";
            // 
            // txtcategoria
            // 
            this.txtcategoria.Location = new System.Drawing.Point(148, 45);
            this.txtcategoria.Name = "txtcategoria";
            this.txtcategoria.Size = new System.Drawing.Size(160, 20);
            this.txtcategoria.TabIndex = 3;
            // 
            // txtdescricao
            // 
            this.txtdescricao.Location = new System.Drawing.Point(148, 94);
            this.txtdescricao.Name = "txtdescricao";
            this.txtdescricao.Size = new System.Drawing.Size(159, 20);
            this.txtdescricao.TabIndex = 4;
            // 
            // txtvalor
            // 
            this.txtvalor.Location = new System.Drawing.Point(147, 151);
            this.txtvalor.Name = "txtvalor";
            this.txtvalor.Size = new System.Drawing.Size(160, 20);
            this.txtvalor.TabIndex = 5;
            // 
            // btgravar
            // 
            this.btgravar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btgravar.Location = new System.Drawing.Point(53, 235);
            this.btgravar.Name = "btgravar";
            this.btgravar.Size = new System.Drawing.Size(82, 31);
            this.btgravar.TabIndex = 6;
            this.btgravar.Text = "Gravar";
            this.btgravar.UseVisualStyleBackColor = true;
            this.btgravar.Click += new System.EventHandler(this.btgravar_Click);
            // 
            // btcancelar
            // 
            this.btcancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btcancelar.Location = new System.Drawing.Point(473, 234);
            this.btcancelar.Name = "btcancelar";
            this.btcancelar.Size = new System.Drawing.Size(97, 31);
            this.btcancelar.TabIndex = 7;
            this.btcancelar.Text = "Cancelar";
            this.btcancelar.UseVisualStyleBackColor = true;
            this.btcancelar.Click += new System.EventHandler(this.btcancelar_Click);
            // 
            // AltCategorias
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(702, 549);
            this.Controls.Add(this.grupo2);
            this.Controls.Add(this.grupo1);
            this.Name = "AltCategorias";
            this.Text = "AltCategorias";
            this.Load += new System.EventHandler(this.AltCategorias_Load);
            this.grupo1.ResumeLayout(false);
            this.grupo1.PerformLayout();
            this.grupo2.ResumeLayout(false);
            this.grupo2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grupo1;
        private System.Windows.Forms.Label lblcodcategoria;
        private System.Windows.Forms.GroupBox grupo2;
        private System.Windows.Forms.Button btalterar;
        private System.Windows.Forms.TextBox txtcodcategoria;
        private System.Windows.Forms.Button btcancelar;
        private System.Windows.Forms.Button btgravar;
        private System.Windows.Forms.TextBox txtvalor;
        private System.Windows.Forms.TextBox txtdescricao;
        private System.Windows.Forms.TextBox txtcategoria;
        private System.Windows.Forms.Label lblvalor;
        private System.Windows.Forms.Label lbldescricao;
        private System.Windows.Forms.Label lblcategoria;
    }
}