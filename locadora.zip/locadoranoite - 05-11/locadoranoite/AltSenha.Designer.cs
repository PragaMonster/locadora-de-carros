﻿namespace locadoranoite
{
    partial class AltSenha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblsenhaatual = new System.Windows.Forms.Label();
            this.lblnovasenha = new System.Windows.Forms.Label();
            this.txtcodfuncionario = new System.Windows.Forms.TextBox();
            this.txtsenhaatual = new System.Windows.Forms.TextBox();
            this.txtnovasenha = new System.Windows.Forms.TextBox();
            this.btalterarsenha = new System.Windows.Forms.Button();
            this.btcancelar = new System.Windows.Forms.Button();
            this.lblcodfuncionario = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblsenhaatual
            // 
            this.lblsenhaatual.AutoSize = true;
            this.lblsenhaatual.Location = new System.Drawing.Point(19, 136);
            this.lblsenhaatual.Name = "lblsenhaatual";
            this.lblsenhaatual.Size = new System.Drawing.Size(65, 13);
            this.lblsenhaatual.TabIndex = 1;
            this.lblsenhaatual.Text = "Senha Atual";
            // 
            // lblnovasenha
            // 
            this.lblnovasenha.AutoSize = true;
            this.lblnovasenha.Location = new System.Drawing.Point(19, 186);
            this.lblnovasenha.Name = "lblnovasenha";
            this.lblnovasenha.Size = new System.Drawing.Size(67, 13);
            this.lblnovasenha.TabIndex = 2;
            this.lblnovasenha.Text = "Nova Senha";
            // 
            // txtcodfuncionario
            // 
            this.txtcodfuncionario.Location = new System.Drawing.Point(105, 92);
            this.txtcodfuncionario.Name = "txtcodfuncionario";
            this.txtcodfuncionario.Size = new System.Drawing.Size(118, 20);
            this.txtcodfuncionario.TabIndex = 3;
            // 
            // txtsenhaatual
            // 
            this.txtsenhaatual.Location = new System.Drawing.Point(102, 134);
            this.txtsenhaatual.Name = "txtsenhaatual";
            this.txtsenhaatual.Size = new System.Drawing.Size(120, 20);
            this.txtsenhaatual.TabIndex = 4;
            // 
            // txtnovasenha
            // 
            this.txtnovasenha.Location = new System.Drawing.Point(96, 185);
            this.txtnovasenha.Name = "txtnovasenha";
            this.txtnovasenha.Size = new System.Drawing.Size(126, 20);
            this.txtnovasenha.TabIndex = 5;
            // 
            // btalterarsenha
            // 
            this.btalterarsenha.Location = new System.Drawing.Point(28, 310);
            this.btalterarsenha.Name = "btalterarsenha";
            this.btalterarsenha.Size = new System.Drawing.Size(122, 35);
            this.btalterarsenha.TabIndex = 6;
            this.btalterarsenha.Text = "Alterar Senha";
            this.btalterarsenha.UseVisualStyleBackColor = true;
            this.btalterarsenha.Click += new System.EventHandler(this.btalterarsenha_Click);
            // 
            // btcancelar
            // 
            this.btcancelar.Location = new System.Drawing.Point(236, 304);
            this.btcancelar.Name = "btcancelar";
            this.btcancelar.Size = new System.Drawing.Size(98, 40);
            this.btcancelar.TabIndex = 7;
            this.btcancelar.Text = "Cancelar";
            this.btcancelar.UseVisualStyleBackColor = true;
            // 
            // lblcodfuncionario
            // 
            this.lblcodfuncionario.AutoSize = true;
            this.lblcodfuncionario.Location = new System.Drawing.Point(15, 94);
            this.lblcodfuncionario.Name = "lblcodfuncionario";
            this.lblcodfuncionario.Size = new System.Drawing.Size(81, 13);
            this.lblcodfuncionario.TabIndex = 8;
            this.lblcodfuncionario.Text = "CodFuncionário";
            // 
            // AltSenha
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 424);
            this.Controls.Add(this.lblcodfuncionario);
            this.Controls.Add(this.btcancelar);
            this.Controls.Add(this.btalterarsenha);
            this.Controls.Add(this.txtnovasenha);
            this.Controls.Add(this.txtsenhaatual);
            this.Controls.Add(this.txtcodfuncionario);
            this.Controls.Add(this.lblnovasenha);
            this.Controls.Add(this.lblsenhaatual);
            this.Name = "AltSenha";
            this.Text = "AltSenha";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblsenhaatual;
        private System.Windows.Forms.Label lblnovasenha;
        private System.Windows.Forms.TextBox txtcodfuncionario;
        private System.Windows.Forms.TextBox txtsenhaatual;
        private System.Windows.Forms.TextBox txtnovasenha;
        private System.Windows.Forms.Button btalterarsenha;
        private System.Windows.Forms.Button btcancelar;
        private System.Windows.Forms.Label lblcodfuncionario;
    }
}