﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

using System.Data.SqlClient;

using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace locadoranoite
{
    public partial class AltCategorias : Form
    {
        private SqlConnection conexao;
        private SqlCommand comando;
        private SqlDataAdapter adapter;
        private DataTable tblcategorias;
        private string strconex, strsql;

        public AltCategorias()
        {
            InitializeComponent();
        }

        private void btalterar_Click(object sender, EventArgs e)
        {
            strconex = "data source=(local);" +
                        "initial catalog = locadora; Integrated security=SSPI";
            conexao = new SqlConnection(strconex);
            conexao.Open();
            strsql = "select * from categorias where codcategoria='" +
                                                        txtcodcategoria.Text + "'";
            adapter = new SqlDataAdapter(strsql, conexao);
            tblcategorias = new DataTable();
            adapter.Fill(tblcategorias);

            if (tblcategorias.Rows.Count == 1)
            {
                txtcategoria.Text = tblcategorias.Rows[0]["Categoria"].ToString();
                txtdescricao.Text = tblcategorias.Rows[0]["Descricao"].ToString();
                txtvalor.Text = tblcategorias.Rows[0]["Valor"].ToString();
                grupo1.Enabled = false;
                grupo2.Enabled = true;
            }
            else
            {
                MessageBox.Show("Registro não existe!", "Aviso",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        private void AltCategorias_Load(object sender, EventArgs e)
        {
            grupo1.Enabled = true;
            grupo2.Enabled = false;

        }

        private void btcancelar_Click(object sender, EventArgs e)
        {
            grupo1.Enabled = true;
            grupo2.Enabled = false;
            txtcategoria.Clear();
            txtdescricao.Clear();
            txtvalor.Clear();
            txtcodcategoria.Clear();
            txtcodcategoria.Focus();
        }

        private void btgravar_Click(object sender, EventArgs e)
        {
            strconex = "data source=(local);" +
                            "initial catalog = locadora; Integrated security=SSPI";
            conexao = new SqlConnection(strconex);
            conexao.Open();

            strsql = "update categorias set categoria='"+txtcategoria.Text+"', descricao='"+txtdescricao.Text+"',valor="+txtvalor.Text.Replace(",",".")+" where codcategoria="+txtcodcategoria.Text+"";
            comando = new SqlCommand(strsql, conexao);
            comando.ExecuteNonQuery();

            MessageBox.Show("Registro Gravado com suceso!",     "Aviso",  MessageBoxButtons.OK, MessageBoxIcon.Information);

            grupo1.Enabled = true;
            grupo2.Enabled = false;

            txtcategoria.Clear();
            txtcodcategoria.Clear();
            txtdescricao.Clear();
            txtvalor.Clear();

        }
    }
}
