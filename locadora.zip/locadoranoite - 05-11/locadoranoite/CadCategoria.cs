﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace locadoranoite
{
    public partial class CadCategoria : Form
    {
        /* para gravar, alterar e exlcuir
         * */
        private SqlConnection conexao;
        private SqlCommand comando;
        private string strconex, strsql;

        public CadCategoria()
        {
            InitializeComponent();
        }

        private void btgravar_Click(object sender, EventArgs e)
        {
            try
            {

                strconex = "data source=(local);initial catalog = locadora;" + "integrated Security=SSPI";

                conexao = new SqlConnection(strconex);
                conexao.Open();

                //para inserção ou deleção use sql conexao e sql command
                strsql = "Insert into categorias (categoria, descricao, valor)    " +
                "    values ('" + txtcategoria.Text + "','" + txtdescricao.Text + "'," + txtvalor.Text.Replace(",", ".") + ")";
                comando = new SqlCommand(strsql, conexao);
                comando.ExecuteNonQuery();

                MessageBox.Show("Registro gravado com sucesso", "aviso",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Erro ao gravar", "aviso",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);


            }
        }

        private void CadCategoria_Load(object sender, EventArgs e)
        {

        }
    }
}
