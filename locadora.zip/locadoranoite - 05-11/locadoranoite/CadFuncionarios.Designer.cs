﻿namespace locadoranoite
{
    partial class CadFuncionarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblcodfuncionario = new System.Windows.Forms.Label();
            this.lblnomefunc = new System.Windows.Forms.Label();
            this.lblendereco = new System.Windows.Forms.Label();
            this.lblbairro = new System.Windows.Forms.Label();
            this.lblcidade = new System.Windows.Forms.Label();
            this.lblcargo = new System.Windows.Forms.Label();
            this.lblusuario = new System.Windows.Forms.Label();
            this.lblsenha = new System.Windows.Forms.Label();
            this.lblnivel = new System.Windows.Forms.Label();
            this.txtcodfuncionario = new System.Windows.Forms.TextBox();
            this.txtnomefunc = new System.Windows.Forms.TextBox();
            this.txtendereco = new System.Windows.Forms.TextBox();
            this.txtbairro = new System.Windows.Forms.TextBox();
            this.txtcidade = new System.Windows.Forms.TextBox();
            this.txtcargo = new System.Windows.Forms.TextBox();
            this.txtusuario = new System.Windows.Forms.TextBox();
            this.txtsenha = new System.Windows.Forms.TextBox();
            this.txtnivel = new System.Windows.Forms.TextBox();
            this.btgravar = new System.Windows.Forms.Button();
            this.btcancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblcodfuncionario
            // 
            this.lblcodfuncionario.AutoSize = true;
            this.lblcodfuncionario.Location = new System.Drawing.Point(20, 52);
            this.lblcodfuncionario.Name = "lblcodfuncionario";
            this.lblcodfuncionario.Size = new System.Drawing.Size(87, 13);
            this.lblcodfuncionario.TabIndex = 0;
            this.lblcodfuncionario.Text = "Cod. Funcionário";
            // 
            // lblnomefunc
            // 
            this.lblnomefunc.AutoSize = true;
            this.lblnomefunc.Location = new System.Drawing.Point(19, 100);
            this.lblnomefunc.Name = "lblnomefunc";
            this.lblnomefunc.Size = new System.Drawing.Size(62, 13);
            this.lblnomefunc.TabIndex = 1;
            this.lblnomefunc.Text = "Nome Func";
            // 
            // lblendereco
            // 
            this.lblendereco.AutoSize = true;
            this.lblendereco.Location = new System.Drawing.Point(20, 147);
            this.lblendereco.Name = "lblendereco";
            this.lblendereco.Size = new System.Drawing.Size(53, 13);
            this.lblendereco.TabIndex = 2;
            this.lblendereco.Text = "Endereço";
            // 
            // lblbairro
            // 
            this.lblbairro.AutoSize = true;
            this.lblbairro.Location = new System.Drawing.Point(22, 195);
            this.lblbairro.Name = "lblbairro";
            this.lblbairro.Size = new System.Drawing.Size(34, 13);
            this.lblbairro.TabIndex = 3;
            this.lblbairro.Text = "Bairro";
            // 
            // lblcidade
            // 
            this.lblcidade.AutoSize = true;
            this.lblcidade.Location = new System.Drawing.Point(23, 243);
            this.lblcidade.Name = "lblcidade";
            this.lblcidade.Size = new System.Drawing.Size(40, 13);
            this.lblcidade.TabIndex = 4;
            this.lblcidade.Text = "Cidade";
            // 
            // lblcargo
            // 
            this.lblcargo.AutoSize = true;
            this.lblcargo.Location = new System.Drawing.Point(22, 285);
            this.lblcargo.Name = "lblcargo";
            this.lblcargo.Size = new System.Drawing.Size(35, 13);
            this.lblcargo.TabIndex = 5;
            this.lblcargo.Text = "Cargo";
            // 
            // lblusuario
            // 
            this.lblusuario.AutoSize = true;
            this.lblusuario.Location = new System.Drawing.Point(22, 340);
            this.lblusuario.Name = "lblusuario";
            this.lblusuario.Size = new System.Drawing.Size(43, 13);
            this.lblusuario.TabIndex = 6;
            this.lblusuario.Text = "Usuário";
            // 
            // lblsenha
            // 
            this.lblsenha.AutoSize = true;
            this.lblsenha.Location = new System.Drawing.Point(23, 393);
            this.lblsenha.Name = "lblsenha";
            this.lblsenha.Size = new System.Drawing.Size(38, 13);
            this.lblsenha.TabIndex = 7;
            this.lblsenha.Text = "Senha";
            // 
            // lblnivel
            // 
            this.lblnivel.AutoSize = true;
            this.lblnivel.Location = new System.Drawing.Point(21, 444);
            this.lblnivel.Name = "lblnivel";
            this.lblnivel.Size = new System.Drawing.Size(33, 13);
            this.lblnivel.TabIndex = 8;
            this.lblnivel.Text = "Nível";
            // 
            // txtcodfuncionario
            // 
            this.txtcodfuncionario.Location = new System.Drawing.Point(128, 48);
            this.txtcodfuncionario.Name = "txtcodfuncionario";
            this.txtcodfuncionario.Size = new System.Drawing.Size(83, 20);
            this.txtcodfuncionario.TabIndex = 9;
            // 
            // txtnomefunc
            // 
            this.txtnomefunc.Location = new System.Drawing.Point(128, 99);
            this.txtnomefunc.Name = "txtnomefunc";
            this.txtnomefunc.Size = new System.Drawing.Size(82, 20);
            this.txtnomefunc.TabIndex = 10;
            // 
            // txtendereco
            // 
            this.txtendereco.Location = new System.Drawing.Point(125, 139);
            this.txtendereco.Name = "txtendereco";
            this.txtendereco.Size = new System.Drawing.Size(84, 20);
            this.txtendereco.TabIndex = 11;
            // 
            // txtbairro
            // 
            this.txtbairro.Location = new System.Drawing.Point(118, 190);
            this.txtbairro.Name = "txtbairro";
            this.txtbairro.Size = new System.Drawing.Size(92, 20);
            this.txtbairro.TabIndex = 12;
            // 
            // txtcidade
            // 
            this.txtcidade.Location = new System.Drawing.Point(118, 242);
            this.txtcidade.Name = "txtcidade";
            this.txtcidade.Size = new System.Drawing.Size(90, 20);
            this.txtcidade.TabIndex = 13;
            // 
            // txtcargo
            // 
            this.txtcargo.Location = new System.Drawing.Point(114, 283);
            this.txtcargo.Name = "txtcargo";
            this.txtcargo.Size = new System.Drawing.Size(96, 20);
            this.txtcargo.TabIndex = 14;
            // 
            // txtusuario
            // 
            this.txtusuario.Location = new System.Drawing.Point(108, 336);
            this.txtusuario.Name = "txtusuario";
            this.txtusuario.Size = new System.Drawing.Size(99, 20);
            this.txtusuario.TabIndex = 15;
            // 
            // txtsenha
            // 
            this.txtsenha.Location = new System.Drawing.Point(109, 390);
            this.txtsenha.Name = "txtsenha";
            this.txtsenha.Size = new System.Drawing.Size(99, 20);
            this.txtsenha.TabIndex = 16;
            // 
            // txtnivel
            // 
            this.txtnivel.Location = new System.Drawing.Point(105, 437);
            this.txtnivel.Name = "txtnivel";
            this.txtnivel.Size = new System.Drawing.Size(102, 20);
            this.txtnivel.TabIndex = 17;
            // 
            // btgravar
            // 
            this.btgravar.Location = new System.Drawing.Point(40, 502);
            this.btgravar.Name = "btgravar";
            this.btgravar.Size = new System.Drawing.Size(114, 41);
            this.btgravar.TabIndex = 18;
            this.btgravar.Text = "Gravar";
            this.btgravar.UseVisualStyleBackColor = true;
            this.btgravar.Click += new System.EventHandler(this.btgravar_Click);
            // 
            // btcancelar
            // 
            this.btcancelar.Location = new System.Drawing.Point(298, 488);
            this.btcancelar.Name = "btcancelar";
            this.btcancelar.Size = new System.Drawing.Size(121, 54);
            this.btcancelar.TabIndex = 19;
            this.btcancelar.Text = "Cancelar";
            this.btcancelar.UseVisualStyleBackColor = true;
            // 
            // CadFuncionarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(542, 588);
            this.Controls.Add(this.btcancelar);
            this.Controls.Add(this.btgravar);
            this.Controls.Add(this.txtnivel);
            this.Controls.Add(this.txtsenha);
            this.Controls.Add(this.txtusuario);
            this.Controls.Add(this.txtcargo);
            this.Controls.Add(this.txtcidade);
            this.Controls.Add(this.txtbairro);
            this.Controls.Add(this.txtendereco);
            this.Controls.Add(this.txtnomefunc);
            this.Controls.Add(this.txtcodfuncionario);
            this.Controls.Add(this.lblnivel);
            this.Controls.Add(this.lblsenha);
            this.Controls.Add(this.lblusuario);
            this.Controls.Add(this.lblcargo);
            this.Controls.Add(this.lblcidade);
            this.Controls.Add(this.lblbairro);
            this.Controls.Add(this.lblendereco);
            this.Controls.Add(this.lblnomefunc);
            this.Controls.Add(this.lblcodfuncionario);
            this.Name = "CadFuncionarios";
            this.Text = "CadFuncionarios";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblcodfuncionario;
        private System.Windows.Forms.Label lblnomefunc;
        private System.Windows.Forms.Label lblendereco;
        private System.Windows.Forms.Label lblbairro;
        private System.Windows.Forms.Label lblcidade;
        private System.Windows.Forms.Label lblcargo;
        private System.Windows.Forms.Label lblusuario;
        private System.Windows.Forms.Label lblsenha;
        private System.Windows.Forms.Label lblnivel;
        private System.Windows.Forms.TextBox txtcodfuncionario;
        private System.Windows.Forms.TextBox txtnomefunc;
        private System.Windows.Forms.TextBox txtendereco;
        private System.Windows.Forms.TextBox txtbairro;
        private System.Windows.Forms.TextBox txtcidade;
        private System.Windows.Forms.TextBox txtcargo;
        private System.Windows.Forms.TextBox txtusuario;
        private System.Windows.Forms.TextBox txtsenha;
        private System.Windows.Forms.TextBox txtnivel;
        private System.Windows.Forms.Button btgravar;
        private System.Windows.Forms.Button btcancelar;
    }
}