﻿namespace locadoranoite
{
    partial class ExcCategorias
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grupo1 = new System.Windows.Forms.GroupBox();
            this.grupo2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtcategoria = new System.Windows.Forms.TextBox();
            this.txtdescricao = new System.Windows.Forms.TextBox();
            this.txtvalor = new System.Windows.Forms.TextBox();
            this.btsim = new System.Windows.Forms.Button();
            this.btnao = new System.Windows.Forms.Button();
            this.btexcluir = new System.Windows.Forms.Button();
            this.txtcodcategoria = new System.Windows.Forms.TextBox();
            this.grupo1.SuspendLayout();
            this.grupo2.SuspendLayout();
            this.SuspendLayout();
            // 
            // grupo1
            // 
            this.grupo1.Controls.Add(this.txtcodcategoria);
            this.grupo1.Controls.Add(this.btexcluir);
            this.grupo1.Controls.Add(this.label1);
            this.grupo1.Location = new System.Drawing.Point(33, 29);
            this.grupo1.Name = "grupo1";
            this.grupo1.Size = new System.Drawing.Size(617, 128);
            this.grupo1.TabIndex = 0;
            this.grupo1.TabStop = false;
            this.grupo1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // grupo2
            // 
            this.grupo2.Controls.Add(this.btnao);
            this.grupo2.Controls.Add(this.btsim);
            this.grupo2.Controls.Add(this.txtvalor);
            this.grupo2.Controls.Add(this.txtdescricao);
            this.grupo2.Controls.Add(this.txtcategoria);
            this.grupo2.Controls.Add(this.label4);
            this.grupo2.Controls.Add(this.label3);
            this.grupo2.Controls.Add(this.label2);
            this.grupo2.Location = new System.Drawing.Point(33, 198);
            this.grupo2.Name = "grupo2";
            this.grupo2.Size = new System.Drawing.Size(616, 337);
            this.grupo2.TabIndex = 1;
            this.grupo2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cod. Categoria";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Categoria";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(44, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Descrição";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(52, 170);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Valor";
            // 
            // txtcategoria
            // 
            this.txtcategoria.Location = new System.Drawing.Point(162, 59);
            this.txtcategoria.Name = "txtcategoria";
            this.txtcategoria.Size = new System.Drawing.Size(301, 20);
            this.txtcategoria.TabIndex = 3;
            this.txtcategoria.TextChanged += new System.EventHandler(this.txtcategoria_TextChanged);
            // 
            // txtdescricao
            // 
            this.txtdescricao.Location = new System.Drawing.Point(162, 105);
            this.txtdescricao.Name = "txtdescricao";
            this.txtdescricao.Size = new System.Drawing.Size(300, 20);
            this.txtdescricao.TabIndex = 4;
            // 
            // txtvalor
            // 
            this.txtvalor.Location = new System.Drawing.Point(162, 166);
            this.txtvalor.Name = "txtvalor";
            this.txtvalor.Size = new System.Drawing.Size(299, 20);
            this.txtvalor.TabIndex = 5;
            // 
            // btsim
            // 
            this.btsim.Location = new System.Drawing.Point(57, 246);
            this.btsim.Name = "btsim";
            this.btsim.Size = new System.Drawing.Size(58, 33);
            this.btsim.TabIndex = 6;
            this.btsim.Text = "Sim";
            this.btsim.UseVisualStyleBackColor = true;
            this.btsim.Click += new System.EventHandler(this.btsim_Click);
            // 
            // btnao
            // 
            this.btnao.Location = new System.Drawing.Point(445, 243);
            this.btnao.Name = "btnao";
            this.btnao.Size = new System.Drawing.Size(67, 35);
            this.btnao.TabIndex = 7;
            this.btnao.Text = "Não";
            this.btnao.UseVisualStyleBackColor = true;
            this.btnao.Click += new System.EventHandler(this.btnao_Click);
            // 
            // btexcluir
            // 
            this.btexcluir.Location = new System.Drawing.Point(518, 46);
            this.btexcluir.Name = "btexcluir";
            this.btexcluir.Size = new System.Drawing.Size(63, 34);
            this.btexcluir.TabIndex = 1;
            this.btexcluir.Text = "Excluir";
            this.btexcluir.UseVisualStyleBackColor = true;
            this.btexcluir.Click += new System.EventHandler(this.btexcluir_Click);
            // 
            // txtcodcategoria
            // 
            this.txtcodcategoria.Location = new System.Drawing.Point(165, 51);
            this.txtcodcategoria.Name = "txtcodcategoria";
            this.txtcodcategoria.Size = new System.Drawing.Size(296, 20);
            this.txtcodcategoria.TabIndex = 2;
            // 
            // ExcCategorias
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(667, 565);
            this.Controls.Add(this.grupo2);
            this.Controls.Add(this.grupo1);
            this.Name = "ExcCategorias";
            this.Text = "ExcCategorias";
            this.Load += new System.EventHandler(this.ExcCategorias_Load);
            this.grupo1.ResumeLayout(false);
            this.grupo1.PerformLayout();
            this.grupo2.ResumeLayout(false);
            this.grupo2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grupo1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grupo2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtvalor;
        private System.Windows.Forms.TextBox txtdescricao;
        private System.Windows.Forms.TextBox txtcategoria;
        private System.Windows.Forms.TextBox txtcodcategoria;
        private System.Windows.Forms.Button btexcluir;
        private System.Windows.Forms.Button btnao;
        private System.Windows.Forms.Button btsim;
    }
}