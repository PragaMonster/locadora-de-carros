﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

using System.Data.SqlClient;

using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace locadoranoite
{
    public partial class CadLocacao : Form
    {
        private SqlConnection conexao;
        private SqlCommand comando;
        private SqlDataAdapter adapter;
        private DataTable tblcli;
        private DataTable tblfunc;
        private DataTable tblveic;
        private string strconex, strsql;
        DateTime devolucao;



        public CadLocacao()
        {
            InitializeComponent();
        }

        private void CadLocacao_Load(object sender, EventArgs e)
        {

            //abrir a conexao com o banco de dados
            strconex = "data source = (local);" + 
                "initial catalog = Locadora;Integrated security=SSPI";
            conexao = new SqlConnection(strconex);
            conexao.Open();

            //carregar a lista de clientes
            strsql = "select * from clientes";
            adapter new SqlDataAdapter(strsql, conexao);
            tblcli = new DataTable ();
            adapter.Fill(tblcli);

            cbocodcli.DataSource = tblcli;
            cbocodcli.DisplayMember = "cliente";
            cbocodcli.ValueMember ="codcliente";
            cbocodcli.Text = "";

            //carregar a lista de funcionários

            strsql="select* from funcionários";
            adapter = new SqlDataAdapter (strsql, conexao);
            tblfunc = new DataTable();
            adapter.Fill(tblfunc);

            cbocodfunc.DataSource = tblfunc;
            cbocodfunc.DisplayMember = "nomefunc";
            cbocodfunc.ValueMember = "codfuncionario";
            cbocodfunc.Text = "";

            //carregar a lista de veiculos

            strsql = "select * from veiculos inner join categorias" + 
                    " on veiculos.codcategoria=categorias.codcategoria";
            adapter = new SqlDataAdapter(strsql, conexao);
            tblveic = new DataTable();
            adapter.Fill(tblveic);

            cbocodvei.DataSource = tblveic;
            cbocodvei.DisplayMember = "modelo";
            cbocodvei.ValueMember ="codveiculo";
            cbocodvei.Text="";

        }

        private void btcancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {
            try
            {
                strsql = "select * from clientes where codcliente = " +
                    cbocodcli.SelectedValue.ToString();
                adapter = new SqlDataAdapter(strsql, conexao);
                tblcli = new DataTable();
                adapter.Fill(tblcli);
                txtcnh.Text = tblcli.Rows[0]["cnh"].ToString();
            }
            catch
            {
            }

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void cbocodfunc_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                strsql = "select * from funcionarios where codfuncionario= " +
                    cbocodfunc.SelectedValue.ToString();
                adapter = new SqlDataAdapter(strsql, conexao);
                tblfunc = new DataTable();
                adapter.Fill(tblfunc);
                txtcargo.Text = tblfunc.Rows[0]["cargo"].ToString();

            }
            catch
            {
            }
        }

        private void cbocodvei_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                strsql = "select * from veiculos inner join categorias" +
                    "on veiculos.codcategoria=categorias.codcategoria " +
                    "where codveiculo =" + cbocodvei.SelectedValue.ToString();

                adapter = new SqlDataAdapter(strsql, conexao);
                tblveic = new DataTable();
                adapter.Fill(tblveic);
                txtplaca.Text = tblveic.Rows[0]["placa"].ToString();
                txtvalor.Text = tblveic.Rows[0]["valor"].ToString();

            }
            catch
            {
            }
        }

        private void dtretirada_ValueChanged(object sender, EventArgs e)
        {
            dtentrega.Value = dtretirada.Value.AddDays(1);//pega a data da retirada (que esta no objeto) adicona um dia e guarda no dtentrega
        }

        private void dtentrega_ValueChanged(object sender, EventArgs e)
        {
            double dias, valorloc;
            devolucao = dtentrega.Value;

            //tem que usar o timespan para guardar o calculo em segundos ou minutos
            TimeSpan data = dtentrega.Value - dtretirada.Value;

            //agora converte em dias e guarda na variavel dias
            dias = data.Days;

            valorloc=dias * Convert.ToDouble(txtvalor.Text)
                txtvalorlocacao.Text = valorloc.ToString();
        }

        private void btcadastro_Click(object sender, EventArgs e)
        {
            try
            {
                strconex = "data source=(local);" +
                    "initial catalog = locadora; Integrated security = SSPI";
                conexao = new SqlConnection(strconex);
                conexao.Open();

                strconex = "insert into locacoes (codcliente, codfuncionario, codveiculo," +
                    "datalocacao, dataretirada,dataentrega,datadevolucao," +
                    "formapagamento,valorlocacao,multa) value    " +
                    "('" + cbocodcli.SelectedValue + "', '" + cbocodfunc.SelectedValue +
                    "','" + dtretirada.Value + "','" + dtentrega.Value + "','" +
                    devolucao + "','" + cboformapag.SelectedText +
                    "','" + txtvalorlocacao.Text + "',0)";
                comando = new SqlCommand(strsql, conexao);
                comando.ExecuteNonQuery();

                MessageBox.Show("Registro gravado com sucesso!",
                    "Aviso",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                Close();
                {
                    MessageBox.Show("Não foi possivel gravar, verifique os dados!",
                        "Alerta",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Exclamation);
            }
        }
    }
}
