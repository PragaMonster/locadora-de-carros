﻿namespace locadoranoite
{
    partial class CadVveiculos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtmodelo = new System.Windows.Forms.TextBox();
            this.txtcor = new System.Windows.Forms.TextBox();
            this.txtano = new System.Windows.Forms.TextBox();
            this.txtplaca = new System.Windows.Forms.TextBox();
            this.txtmarca = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbocodcategoria = new System.Windows.Forms.ComboBox();
            this.btgravar = new System.Windows.Forms.Button();
            this.btcancelar = new System.Windows.Forms.Button();
            this.lblcodcategoria = new System.Windows.Forms.Label();
            this.txtimagem = new System.Windows.Forms.TextBox();
            this.lbl = new System.Windows.Forms.Label();
            this.btok = new System.Windows.Forms.Button();
            this.picimagem = new System.Windows.Forms.PictureBox();
            this.open = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.picimagem)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Marca:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Modelo:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Cor:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 153);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Placa:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 191);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Ano:";
            // 
            // txtmodelo
            // 
            this.txtmodelo.Location = new System.Drawing.Point(115, 71);
            this.txtmodelo.Name = "txtmodelo";
            this.txtmodelo.Size = new System.Drawing.Size(137, 20);
            this.txtmodelo.TabIndex = 5;
            // 
            // txtcor
            // 
            this.txtcor.Location = new System.Drawing.Point(115, 111);
            this.txtcor.Name = "txtcor";
            this.txtcor.Size = new System.Drawing.Size(137, 20);
            this.txtcor.TabIndex = 6;
            // 
            // txtano
            // 
            this.txtano.Location = new System.Drawing.Point(115, 191);
            this.txtano.Name = "txtano";
            this.txtano.Size = new System.Drawing.Size(137, 20);
            this.txtano.TabIndex = 8;
            // 
            // txtplaca
            // 
            this.txtplaca.Location = new System.Drawing.Point(115, 153);
            this.txtplaca.Name = "txtplaca";
            this.txtplaca.Size = new System.Drawing.Size(137, 20);
            this.txtplaca.TabIndex = 9;
            // 
            // txtmarca
            // 
            this.txtmarca.Location = new System.Drawing.Point(115, 26);
            this.txtmarca.Name = "txtmarca";
            this.txtmarca.Size = new System.Drawing.Size(137, 20);
            this.txtmarca.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 233);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Categoria:";
            // 
            // cbocodcategoria
            // 
            this.cbocodcategoria.FormattingEnabled = true;
            this.cbocodcategoria.Location = new System.Drawing.Point(115, 233);
            this.cbocodcategoria.Name = "cbocodcategoria";
            this.cbocodcategoria.Size = new System.Drawing.Size(137, 21);
            this.cbocodcategoria.TabIndex = 12;
            this.cbocodcategoria.SelectedIndexChanged += new System.EventHandler(this.cbocodcategoria_SelectedIndexChanged);
            // 
            // btgravar
            // 
            this.btgravar.Location = new System.Drawing.Point(15, 304);
            this.btgravar.Name = "btgravar";
            this.btgravar.Size = new System.Drawing.Size(91, 23);
            this.btgravar.TabIndex = 13;
            this.btgravar.Text = "Gravar";
            this.btgravar.UseVisualStyleBackColor = true;
            this.btgravar.Click += new System.EventHandler(this.btgravar_Click);
            // 
            // btcancelar
            // 
            this.btcancelar.Location = new System.Drawing.Point(161, 304);
            this.btcancelar.Name = "btcancelar";
            this.btcancelar.Size = new System.Drawing.Size(91, 23);
            this.btcancelar.TabIndex = 14;
            this.btcancelar.Text = "Cancelar";
            this.btcancelar.UseVisualStyleBackColor = true;
            this.btcancelar.Click += new System.EventHandler(this.btcancelar_Click);
            // 
            // lblcodcategoria
            // 
            this.lblcodcategoria.AutoSize = true;
            this.lblcodcategoria.Location = new System.Drawing.Point(287, 238);
            this.lblcodcategoria.Name = "lblcodcategoria";
            this.lblcodcategoria.Size = new System.Drawing.Size(16, 13);
            this.lblcodcategoria.TabIndex = 15;
            this.lblcodcategoria.Text = "...";
            // 
            // txtimagem
            // 
            this.txtimagem.Enabled = false;
            this.txtimagem.Location = new System.Drawing.Point(290, 74);
            this.txtimagem.Name = "txtimagem";
            this.txtimagem.Size = new System.Drawing.Size(137, 20);
            this.txtimagem.TabIndex = 16;
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Location = new System.Drawing.Point(287, 32);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(47, 13);
            this.lbl.TabIndex = 17;
            this.lbl.Text = "Imagem:";
            // 
            // btok
            // 
            this.btok.Location = new System.Drawing.Point(433, 71);
            this.btok.Name = "btok";
            this.btok.Size = new System.Drawing.Size(52, 23);
            this.btok.TabIndex = 18;
            this.btok.Text = "ok";
            this.btok.UseVisualStyleBackColor = true;
            this.btok.Click += new System.EventHandler(this.btok_Click);
            // 
            // picimagem
            // 
            this.picimagem.Location = new System.Drawing.Point(290, 100);
            this.picimagem.Name = "picimagem";
            this.picimagem.Size = new System.Drawing.Size(137, 104);
            this.picimagem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picimagem.TabIndex = 19;
            this.picimagem.TabStop = false;
            // 
            // open
            // 
            this.open.FileName = "openFileDialog1";
            // 
            // CadVveiculos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(498, 352);
            this.Controls.Add(this.picimagem);
            this.Controls.Add(this.btok);
            this.Controls.Add(this.lbl);
            this.Controls.Add(this.txtimagem);
            this.Controls.Add(this.lblcodcategoria);
            this.Controls.Add(this.btcancelar);
            this.Controls.Add(this.btgravar);
            this.Controls.Add(this.cbocodcategoria);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtmarca);
            this.Controls.Add(this.txtplaca);
            this.Controls.Add(this.txtano);
            this.Controls.Add(this.txtcor);
            this.Controls.Add(this.txtmodelo);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "CadVveiculos";
            this.Text = "CadVveiculos";
            this.Load += new System.EventHandler(this.CadVveiculos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picimagem)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtmodelo;
        private System.Windows.Forms.TextBox txtcor;
        private System.Windows.Forms.TextBox txtano;
        private System.Windows.Forms.TextBox txtplaca;
        private System.Windows.Forms.TextBox txtmarca;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbocodcategoria;
        private System.Windows.Forms.Button btgravar;
        private System.Windows.Forms.Button btcancelar;
        private System.Windows.Forms.Label lblcodcategoria;
        private System.Windows.Forms.TextBox txtimagem;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.Button btok;
        private System.Windows.Forms.PictureBox picimagem;
        private System.Windows.Forms.OpenFileDialog open;
    }
}