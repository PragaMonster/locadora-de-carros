﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

using System.Data.SqlClient;

using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace locadoranoite
{
    public partial class ExcCategorias : Form
    {
        private SqlConnection conexao;
        private SqlCommand comando;
        private SqlDataAdapter adapter;
        private DataTable tblcategorias;
        private string strconex, strsql;
        public ExcCategorias()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void ExcCategorias_Load(object sender, EventArgs e)
        {
            grupo1.Enabled = true;
            grupo2.Visible = false;
        }

        private void btnao_Click(object sender, EventArgs e)
        {
            grupo1.Enabled = true;
            grupo2.Visible = false;
        }

        private void txtcategoria_TextChanged(object sender, EventArgs e)
        {

        }

        private void btexcluir_Click(object sender, EventArgs e)
        {
            strconex = "data source=(local);" +
                        "initial catalog = locadora; Integrated security=SSPI";
            conexao = new SqlConnection(strconex);
            conexao.Open();

            strsql = "select * from categorias where codcategoria = '" +
                                                             txtcodcategoria.Text + "'";
            adapter = new SqlDataAdapter(strsql, conexao);
            tblcategorias = new DataTable();
            adapter.Fill(tblcategorias);

            if (tblcategorias.Rows.Count ==1)
            {
                txtcategoria.Text = tblcategorias.Rows[0]["Categoria"].ToString();
                txtdescricao.Text = tblcategorias.Rows[0]["Descricao"].ToString();
                txtvalor.Text = tblcategorias.Rows[0]["valor"].ToString();
                grupo1.Enabled = false;
                grupo2.Visible = true;
            }
            else
            {
            MessageBox.Show("Registro não existe", "Aviso",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            }
        }

        private void btsim_Click(object sender, EventArgs e)
        {
            try
            {
                strconex = "data source=(local);" +
                    "initial catalog = locadora; integrated security = sspi";
                conexao = new SqlConnection(strconex);
                conexao.Open();

                strsql = "delete from categorias where codcategoria = '" + txtcodcategoria.Text + "'";
                comando = new SqlCommand(strsql, conexao);
                comando.ExecuteNonQuery();

                MessageBox.Show("Registro excluido com sucesso!", 
                    "Aviso",
                  MessageBoxButtons.OK,
                  MessageBoxIcon.Information);
                grupo1.Enabled = true;
                grupo2.Visible = false;

                txtcategoria.Clear();
                txtcodcategoria.Clear();
                txtdescricao.Clear();
                txtvalor.Clear();
            }
            catch
            {
                MessageBox.Show("Erro ao exlcuir o registro, verifique se esta"+
                        "Não possui ligação com outra tabela!!",
                        "Aviso",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
            }
        }
        }
    }


