﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace locadoranoite
{
    public partial class Principal : Form
    {
        public string nome;
        public string nivel;

        public Principal()
        {
            InitializeComponent();
        }

        private void Principal_Load(object sender, EventArgs e)
        {
            this.Text = "olá Sr(a) ... "+nome;

            if (nivel == "1")
            {
                relatórioToolStripMenuItem.Visible = false;
                apagarToolStripMenuItem.Visible = false;
            }
            else if (nivel == "2")
            {
                relatórioToolStripMenuItem.Visible = false;
            }
        }

        private void clienteToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void Principal_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void categoriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CadCategoria categ = new CadCategoria();
            categ.Show();
        }
    }
}
